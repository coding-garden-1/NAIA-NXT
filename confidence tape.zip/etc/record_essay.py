import traceback
import os
from openai import OpenAI

def transcribe_audio(audio_file):
    """
    Transcribe the given audio file using OpenAI API.

    Parameters:
        audio_file (str): The path to the audio file.

    Returns:
        str: The transcription text.
    """
    try:
        client = OpenAI(api_key='sk-proj-UgtG9PNt8mDorNwarHNoT3BlbkFJ9VA25Kx2wraorpujw8uw')

        with open(audio_file, "rb") as file:
            transcription = client.audio.transcriptions.create(
                model="whisper-1",
                file=file
            )
            return transcription.text
    except Exception as e:
        print("Error occurred during transcription:", e)
        traceback.print_exc()
        return None

try:
    cwd = os.getcwd()
    mp3_files = [file for file in os.listdir(cwd) if file.endswith('.mp3')]

    if not mp3_files:
        print("No MP3 files found in the current directory.")
    else:
        for mp3_file in mp3_files:
            print(f"Transcribing {mp3_file}...")
            transcription = transcribe_audio(mp3_file)
            if transcription:
                print(transcription)
            else:
                print(f"Failed to transcribe {mp3_file}.")
except Exception as e:
    print("Error occurred:", e)
    traceback.print_exc()
