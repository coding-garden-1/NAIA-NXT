I exist in wealth, not poverty.
I am a wealthy person, not a poor person.
Any unwanted ideas about my life dissolve permanently and is replaced with a peaceful feeling worthy of me. 
I align with peaceful realities permanently.
I forever live in a life that is safe for me.
I forever live in a life that is protective of me.
I forever live in a life that is enjoyable for me. 
I am able to put away any thoughts that do not need to concern me.
I am able to recognize what is not my responsibility to change.
I am able to feel happy and grounded in enjoyable days that do not try too hard or search for any power outside my own power.
I am my own key; in every situation I look inwards to how I feel about myself.
I feel amazing about myself and I am always accomplishing the best feats within myself.
I am able to release any negative attachments that do not match my God identity.
Nothing can harm me and nothing can change my beliefs I declare within myself.
I am able to release all fear and disbelief.
I always do well in life and am friends with the right people at all time.
i easily defuse and eliminate any anxieties; I am peace. 
i am always going forward without the need for permission
i always experience the best portions of life and support is given to me every day.
I release any fears or doubts, and I live abundant and happy every day.
I released any burden, confusion or fear that surrounds my ability to respond to my own manifested outcomes.
I know exactly what i am doing and no part of me or my life is in danger.
I have the final say in what goes on in my life, and I am never intimidated.
I am so happy because I love my life and all the amazing ways I spend my time.
I am so happy that everything worked out perfectly and I did not wait to see anything physical to feel like things worked out.
I never wait for physical results; I become the fearless me in this moment.
I feel so fearless, vibrant, healthy, thriving, enjoying, socially connected, and connected to every part of my strength.
I feel like a God, with no fear in me at all.
I have no doubt in my mind that things are working out just as I want them.




I am the positive energy I decide to feel. I am the solution. I am the answer. I am trusting my power and my identity. I am never afraid of who I am and I am never afraid of my perceptions. I always have the strongest perceptions that make the best results.










There are a million ways the assistance that i need to always get into college and go to school for free comes to me 
Paperwork and documents always magically appear in order and on time for college
I do not worry about anything that somebody else is paid to worry about and handle 
I know how to easily apply and receive for all scholarships that put me through school, without losing any sleep
Not a single thing has ever stopped me from achieving financial aide that put me through school 
School and everything required to attend school is already paid for 

College is a fun and easy next step in my life
All of my bills are footed and I’m living comfortably and stress free
I have as much money coming in that i want
I always show up as somebody that is able to receive payments or wealth without any issue
I am never concerned about money or desperate for checks to come in
I own a luxury business model and attract eager and financially abundant clients
It is easy for me to receive, save and intelligently allocate my sustainment with incoming money
Manifesting money from scratch is my birth right and always successful for me

financial aide comes to me in every form because that is my intention and the rest works out for me. nothing can ever intimdate me.
I chose love when i imagined that college would be excited and happy to sign my letter and give me full financial aid
innovative and easy solutions are created immediately to address and eliminate all issues
all of the appropriate documentation and paperwork to facilitate my college entrance and attendance is completed in perfect order
know exactly how to obtain the financial aide needed to attend the college of my choice
getting full aid is easy

i bypass the standard time line of receiving financial aid, all worry is immediately abolished as i always receive favors and blessings
financial aid or assistances are always more than sufficient for me to attend school<br>i do not have any concerns with financial aid because i have no lack. i feel safe in the world and human with my abundance. i am so blessed with so much richness. <br>i cannot bow under stress or fear--i am always abundant in peace. <br> 