from youtube_transcript_api import YouTubeTranscriptApi
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
import os 

# Replace 'YOUR_API_KEY' with your actual YouTube Data API key
API_KEY = 'AIzaSyBFVIawpc_-MBNuECAX9nDvqKXcWdGTE0c'

def get_channel_videos(channel_id):
    youtube = build('youtube', 'v3', developerKey=API_KEY)
 
    # Retrieve playlist ID for uploaded videos of the channel
    uploads_playlist_response = youtube.channels().list(
        part='contentDetails',
        id=channel_id
    ).execute()
    print("got playlist ID of all the videos ...")
    uploads_playlist_id = uploads_playlist_response['items'][0]['contentDetails']['relatedPlaylists']['uploads']

    # Retrieve videos from the uploads playlist
    playlist_items = []
    next_page_token = None

    while True:
        playlist_items_response = youtube.playlistItems().list(
            part='snippet',
            playlistId=uploads_playlist_id,
            maxResults=150,
            pageToken=next_page_token
        ).execute()

        playlist_items += playlist_items_response['items']
        print('got a video')
        next_page_token = playlist_items_response.get('nextPageToken')

        if not next_page_token:
            break

    return playlist_items

def get_transcripts(channel_id):
    videos = get_channel_videos(channel_id)
    transcripts = {}

    for video in videos:
        video_id = video['snippet']['resourceId']['videoId']
        title = video['snippet']['title']
        
        try:
            transcript = YouTubeTranscriptApi.get_transcript(video_id)
            text = ' '.join([line['text'] for line in transcript])
            transcripts[title] = text
            # Save transcript to a text file
            with open(f"{title}.txt", "w", encoding="utf-8") as file:
                file.write(text)
            print("exported a transcript")
        except Exception as e:
            transcripts[title] = f"Transcript not available: {str(e)}"

    return transcripts

# Example usage:
os.chdir("dylan_transcripts")
channel_id = 'UC96Ek-bKKFbRESy8JYvlq-A'
transcripts = get_transcripts(channel_id)
for title, transcript in transcripts.items():
    print(f"Title: {title}\nTranscript saved to file.\n")
