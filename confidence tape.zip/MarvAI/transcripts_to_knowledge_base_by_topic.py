import os
import re
import csv

def extract_topics(sentence):
    topics = {
        'overcoming_circumstances': ['circumstances', 'challenges', 'life'],
        'relationship_mindset': ['relationship', 'love life', 'partner'],
        'emotional_self_regulation': ['emotional self-regulation', 'managing emotions'],
        'subconscious_beliefs': ['subconscious beliefs', 'limiting beliefs'],
        'self_concept': ['self concept', 'self perception']
    }
    
    for topic, keywords in topics.items():
        for keyword in keywords:
            if re.search(r'\b' + re.escape(keyword) + r'\b', sentence, re.IGNORECASE):
                return topic
    
    return None

def categorize_sentences(transcript_text):
    sentences = re.split(r'(?<=[.!?])\s+', transcript_text)
    categorized_sentences = []

    for sentence in sentences:
        topic = extract_topics(sentence)
        categorized_sentences.append((sentence, topic))
    
    return categorized_sentences

def save_to_csv(categorized_sentences, output_file='topics.csv'):
    with open(output_file, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = ['Sentence', 'Topic']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        for sentence, topic in categorized_sentences:
            writer.writerow({'Sentence': sentence, 'Topic': topic})

def main():
    transcripts_directory = 'dylan_transcripts'
    output_file = 'topics.csv'
    
    categorized_sentences = []
    
    # Iterate over each transcript in the directory
    for filename in os.listdir(transcripts_directory):
        if filename.endswith('.txt'):
            with open(os.path.join(transcripts_directory, filename), 'r', encoding='utf-8') as file:
                transcript_text = file.read()
                categorized_sentences.extend(categorize_sentences(transcript_text))
    
    # Save to CSV
    save_to_csv(categorized_sentences, output_file=output_file)

if __name__ == "__main__":
    main()
