from pydub import AudioSegment
import re
from gtts import gTTS

def generate_audio_gtts(text_content, filename):
    tts = gTTS(text=text_content, lang='en')
    tts.save(f'{filename}.mp3')
    print(f'Audio file "{filename}.mp3" generated successfully')
    return f'{filename}.mp3'

def concatenate_audio(audio_files, output_filename):
    final_audio = AudioSegment.empty()
    for i, audio_file in enumerate(audio_files):
        audio_segment = AudioSegment.from_file(audio_file)
        final_audio += audio_segment
        # Add twenty seconds of silence after each audio file except the last one
        if i < len(audio_files) - 1 or len(audio_files) == 1:
            final_audio += AudioSegment.silent(duration=20000)

    # Increase the volume by 25%
    final_audio = final_audio + 2

    final_audio.export(output_filename, format="mp3")
    print(f'Concatenated audio saved as "{output_filename}"')

def split_into_sentences(text):
    # Split text into sentences using regular expression
    sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?|\!|\-)\s', text)
    return sentences

def eleven_labs_voice_generation(text_content, filename):
    sentences = split_into_sentences(text_content)
    audio_files = []

    for i, sentence in enumerate(sentences):
        # Clean up any leading or trailing whitespace
        sentence = sentence.strip()
        if sentence:
            audio_file = generate_audio_gtts(sentence, f'{filename}_{i}')
            if audio_file:
                audio_files.append(audio_file)

    if audio_files:
        concatenate_audio(audio_files, f'{filename}_final_output.mp3')

# Example usage:
with open('tape.txt', 'r') as file:
    text_content = file.read()

eleven_labs_voice_generation(text_content, "meditate_tape")